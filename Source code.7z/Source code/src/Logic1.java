/*
 * this is the agent for RPS.
 */
public class Logic1 {
	public Logic1(Game game) {
		play(game);
	}

	public void play(Game game) {
		System.out.println("----------RPS----------");
		int x, y;
		//if there is any cell have not probed and the live is not equals to 0, continue to probe next cell
		while (game.countDanger(game)!=game.countMark(game) && game.life != 0) {
			//create the coordinate 
			x = (int) (Math.random() * game.map.length);
			y = (int) (Math.random() * game.map.length);
			//probe the cell
			if (game.cover[x][y]&&!game.mark[x][y]) {
				//the cell is gold
				if (game.probe(x, y) == 1) {
					game.life++;
					game.uncover(x, y);
					System.out.println("reveal" + " " + x + "," + y + " " + "life:" + " " + game.life);
					System.out.println("goldmine-in" + " " + x + "," + y + ", life count 1 " + "Life:" + game.life);
					System.out.println(game);
				}
				//the cell is danger
				if (game.probe(x, y) == -1) {
					game.life--;
					game.mark(x, y);
					System.out.println("reveal" + " " + x + "," + y + " " + "life:" + " " + game.life);
					System.out.println("dagger-in" + " " + x + "," + y + ", life minus l " + "Life:" + game.life);
					if(game.life==0) {
						System.out.println("GAME LOST");
					}
					System.out.println(game);
				}
				//the cell is number
				if (game.probe(x, y) == 0) {
					game.uncover(x, y);
					System.out.println("reveal" + " " + x + "," + y + " " + "life:" + " " + game.life);
					System.out.println(game);
				}
				
				//all dangers have been marked
				if(game.countDanger(game)==game.countMark(game)&&game.life!=0) {
					System.out.println("GAME WIN ");
					game.win++;
					for(int i=0;i<game.cover.length;i++) {
						for(int z=0;z<game.cover[i].length;z++) {
							if(game.cover[i][z]) {
								game.uncover(i, z);
							}
						}
					}
					System.out.println(game);
				}
				//the last covered cell is danger
				if((game.countMark(game)+game.countUncovered(game))==(game.N*game.N-1)&&game.life!=0) {
					for(int i=0;i<game.cover.length;i++) {
						for(int z=0;z<game.cover[i].length;z++) {
							if(game.cover[i][z]&&game.map[i][z].equals("d")&&!game.mark[i][z]) {
								game.mark(i, z);
								System.out.println("The last cell is a danger");
								System.out.println("YOU WIN");
								game.win++;
								System.out.println(game);
							}
						}
					}
				}
			}
		}
	}

	public static void main(String[] args) {
		if(args.length != 1 ) {
			System.out.println("please input the right param");
			System.exit(0);
		}
		selectMap selecter = new selectMap();
		World map = selecter.select(args[0]);
		try {
			Game game = new Game(map);
			Logic1 agent = new Logic1(game);
		} catch (Exception e) {
			System.out.println("please input the right param");
		}
		
		
	}
}

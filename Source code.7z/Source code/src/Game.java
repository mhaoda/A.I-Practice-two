/*
 * This is the class for the game infrastructure.
 */
public class Game {
	int N;
	int life;
	int win;
	String[][] map;
	boolean[][] mark;
	boolean[][] cover;
	boolean[][] looked;
	public Game(World world) {
		this.life = 1;
		this.N = world.map.length;
		this.map = world.map;
		this.mark = new boolean[this.N][this.N];
		this.cover = new boolean[this.N][this.N];
		this.looked = new boolean[this.N][this.N];
		//Initialise the array of the cover, the mark and the cell that has been probed.
		for(int m=0;m<this.cover.length;m++) {
			for(int n=0;n<this.cover[0].length;n++) {
				this.cover[m][n] = true;
			}
		}
		for(int m=0;m<this.mark.length;m++) {
			for(int n=0;n<this.mark[0].length;n++) {
				this.mark[m][n] = false;
			}
		}
		for(int m=0;m<this.looked.length;m++) {
			for(int n=0;n<this.looked[0].length;n++) {
				this.looked[m][n] = false;
			}
		}
	}

	public int getLife() {
		return life;
	}
	
	public int probe(int x, int y) {
		if (map[x][y].equals("d")) {
			return -1;
		}
		if (map[x][y].equals("g")) {
			return 1;
		} else {
			return 0;
		}

	}
	//Count the number of the danger in the map.
	public int countDanger(Game game) {
		int danger = 0;
		for(int i=0;i<game.map.length;i++) {
			for(int z = 0;z<game.map[i].length;z++) {
				if(game.map[i][z].equals("d")) {
					danger++;
				}
			}
		}
		return danger;
	} 
	//Count the number of the marked cell in the map.
	public int countMark(Game game) {
		int marked = 0;
		for(int i=0;i<game.mark.length;i++) {
			for(int z = 0;z<game.mark[i].length;z++) {
				if(game.mark[i][z]) {
					marked++;
				}
			}
		}
		return marked;
	}
	//Count the number of the open cell in the map.
	public int countUncovered(Game game) {
		int uncovered = 0;
		for(int i=0;i<game.cover.length;i++) {
			for(int z = 0;z<game.cover[i].length;z++) {
				if(!game.cover[i][z]) {
					uncovered++;
				}
			}
		}
		return uncovered;
	}
	
	public void mark(int x, int y) {
		mark[x][y] = true;
	}
	
	public void uncover(int x, int y) {
		cover[x][y] = false;
	}
	//Rewrite the toString method, make the result print clearer.
	public String toString() {
		String s = "";
		for (int i = 0; i < this.N; i++) {
			for (int y = 0; y < this.N; y++) {
				if (this.mark[i][y]) {
					s += "X ";
				} else if(this.cover[i][y]) {
					s += "? ";
				} else {
					s += this.map[i][y] + " ";
				}
				
			}
			s += "\n";
		}
		
		return s;
	}
}

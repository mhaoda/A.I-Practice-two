/*
 * This is the class for single point strategy.
 */
import java.util.ArrayList;

public class Logic2 {
	int call;
	int win;
	public Logic2(Game game) {
		this.call = play(game);
	}
	//Collecting the neighbours around the cell.
	public ArrayList<Cell> getCandinates(int m, int n, Game game) {
		ArrayList<Cell> candinates = new ArrayList<Cell>();
		for (int x = m - 1; x <= m + 1; x++) {
			if (x >= 0 && x < game.map.length) {
				for (int y = n - 1; y <= n + 1; y++) {
					if (y >= 0 && y < game.map[x].length) {
						candinates.add(new Cell(x, y, game.map[x][y]));
					}
				}
			}
		}
		return candinates;
	}

	public int play(Game game) {
		// begin on the top-left
		System.out.println("--------SPS--------");
		game.cover[0][0] = false;
		int call;
		do {
			call = 0;
			for (int m = 0; m < game.map.length; m++) {
				for (int n = 0; n < game.map[m].length; n++) {
					if (!game.cover[m][n]||game.mark[m][n]) {
						continue;
					}

					ArrayList<Cell> neighbours = getCandinates(m, n, game);
					for (int i = 0; i < neighbours.size(); i++) {
						// check every clues from uncovered neighbours
						if (!game.cover[neighbours.get(i).x][neighbours.get(i).y]) {
							if (AFNRule(neighbours.get(i), game)) {
								// uncover m,n
								System.out.println("reveal" + " " + m + "," + n + " " + "life:" + " " + game.life);
								if (game.probe(m, n) == 1) {
									game.life++;
									System.out.println("goldmine-in" + " " + m + "," + n + ", life count 1 " +"Life:" +game.life);
								}
								game.uncover(m, n);
								System.out.println(game);
								call++;
								break;
							} else if (AMNRule(neighbours.get(i), game)) {
								// mark m, n
								System.out.println("reveal" + " " + m + "," + n + "it is danger, marked " + "life:" + " " + game.life);
								game.mark(m, n);
								System.out.println(game);
								call++;
								break;
							}
						}
					}

				}
			}
		} while (call != 0);
		//The game will finish when the agent marks all dangers.
		if(game.countDanger(game)==game.countMark(game)&&game.life!=0) {
			System.out.println("GAME WIN (SPS)");
			game.win++;
			for(int i=0;i<game.cover.length;i++) {
				for(int z=0;z<game.cover[i].length;z++) {
					if(game.cover[i][z]) {
						game.uncover(i, z);
					}
				}
			}
			System.out.println(game);
			System.exit(0);
		}else {
			//Game is not finish, prepare to start RPS.
			int count = 0;
			for(int i=0;i<game.map.length;i++) {
				for(int z=0;z<game.map[i].length;z++) {
					if(game.cover[i][z]&&!game.mark[i][z]) {
						count++;
					}
				}
			}
			System.out.println("STILL HAVE " + count + " COVERED CELLS");
		}
		return call;
	}
	//All free neighbours
	public boolean AFNRule(Cell c, Game game) {
		int dangerNum = 0;
		ArrayList<Cell> neighbours = getCandinates(c.x, c.y, game);
		for (int i = 0; i < neighbours.size(); i++) {
			if (game.mark[neighbours.get(i).x][neighbours.get(i).y]) {
				dangerNum++;
			}
		}
		if (c.getValue() == dangerNum) {
			return true;
		} else {
			return false;
		}
	}
	//All mark neighbours
	public boolean AMNRule(Cell c, Game game) {
		int markNum = 0;
		int coverNum = 0;
		ArrayList<Cell> neighbours = new ArrayList<Cell>();
		neighbours = getCandinates(c.x, c.y, game);
		// the number of the cell covered is equals to the number of the danger
		for (int i = 0; i < neighbours.size(); i++) {
			if (game.cover[neighbours.get(i).x][neighbours.get(i).y]&&!game.mark[neighbours.get(i).x][neighbours.get(i).y]) {
				coverNum++;
			}
		}
		for (int i = 0; i < neighbours.size(); i++) {
			if (game.mark[neighbours.get(i).x][neighbours.get(i).y]) {
				markNum++;
			}
		}
		if (c.getValue() - markNum == coverNum) {
			return true;
		} else {
			return false;
		}
	}

	public static void main(String[] args) {
		if(args.length != 1 ) {
			System.out.println("please input the right param");
			System.exit(0);
		}
		selectMap selecter = new selectMap();
		World map = selecter.select(args[0]);
		
		try {
			Game game = new Game(map);	
			Logic2 SPS = new Logic2(game);
			Logic1 RPS = new Logic1(game);
		} catch (Exception e) {
			System.out.println("please input the right param");
		}
		
	
	}
}


/*
 * This is the class for logical agent.
 */
import java.util.ArrayList;

import org.logicng.io.parsers.ParserException;

public class Logic3 {
	int live;

	public Logic3(Game game) {
		this.live = game.getLife();
	}

	public void play(Game game) {
		String KBU = "";
		Logic3 l = new Logic3(game);
		int callSPS = 0, callAST = 0;
		KBU k = new KBU();
		int call = 0;
		do {
			// Start with the SPS.
			Logic2 sps = new Logic2(game);
			callSPS = sps.call;
			// Generating the knowledge base.
			KBU = k.creatKBU(game);
			//Start AST when the SPS stop working.
			if (callSPS == 0 && game.countDanger(game) != game.countMark(game)) {
				callAST = l.AST(game, KBU);
				KBU = k.creatKBU(game);
			}
			//Game over when the agent finds all dangers.
			if (game.countDanger(game) == game.countMark(game) && game.life != 0) {
				System.out.println("FIND ALL DANGER");
				System.out.println("GAME WIN (Logical)");
				game.win++;
				for (int i = 0; i < game.cover.length; i++) {
					for (int z = 0; z < game.cover[i].length; z++) {
						if (game.cover[i][z]) {
							game.uncover(i, z);
						}
					}
				}
				System.out.println(game);
				System.exit(0);
			} else {
				//Prepare enter another strategy.
				int count = 0;
				for (int i = 0; i < game.map.length; i++) {
					for (int z = 0; z < game.map[i].length; z++) {
						if (game.cover[i][z] && !game.mark[i][z]) {
							count++;
						}
					}
				}
				System.out.println("STILL HAVE " + count + " COVERED CELLS");
			}
			call = callSPS + callAST;
		} while (call != 0);
		//Start RPS
		Logic1 rps = new Logic1(game);
	}

	public int AST(Game game, String KBU) {
		System.out.println("--------AST----------");
		int call = 0;
		Logic3 l = new Logic3(game);
		LoginNG ln = new LoginNG();
		SAT s = new SAT();
		//Put the probing cell into the knowledge base to test its satisfiability.
		for (int i = 1; i < game.map.length; i++) {
			for (int y = 1; y < game.map[i].length; y++) {
				if (game.cover[i][y] && !game.mark[i][y]) {
					String KBUTest = KBU;
					String currentCell = "&(~D" + i + y + ")";
					KBUTest = KBUTest + currentCell;
					KBUTest = KBUTest.replaceAll("D", "");
					KBUTest = KBUTest.replaceAll(" ", "");
					// System.out.println(KBUT);
					try {
						call = call + s.SAT(ln.loginNG(KBUTest), game, new Cell(i, y, game.map[i][y]));
						//If the problem is not satisfiable, mark the proving cell.
						if (s.SAT(ln.loginNG(KBUTest), game, new Cell(i, y, game.map[i][y])) != 0) {
							KBU = KBU + "&(D" + i + y + ")";
							System.out.println(
									"reveal" + " " + i + "," + y + " is danger, marked " + "life:" + " " + game.life);
							System.out.println(game);
						}
					} catch (ParserException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}
		return call;
	}
	//Collecting the neighbours around the cell.
	public ArrayList<Cell> getCandinates(int m, int n, Game game) {
		ArrayList<Cell> candinates = new ArrayList<Cell>();
		for (int x = m - 1; x <= m + 1; x++) {
			if (x >= 0 && x < game.map.length) {
				for (int y = n - 1; y <= n + 1; y++) {
					if (y >= 0 && y < game.map[x].length) {
						candinates.add(new Cell(x, y, game.map[x][y]));
					}
				}
			}
		}
		return candinates;
	}

	public static void main(String[] args){

		if (args.length != 1) {
			System.out.println("please input the right param");
			System.exit(0);
		}
		selectMap selecter = new selectMap();
		World map = selecter.select(args[0]);
		
		try {
			Game game = new Game(map);
			Logic3 AST = new Logic3(game);
			AST.play(game);
		} catch (Exception e) {
			System.out.println("please input the right param");
		}

	}
}


import java.util.ArrayList;

import org.sat4j.core.VecInt;
import org.sat4j.pb.SolverFactory;
import org.sat4j.specs.ContradictionException;
import org.sat4j.specs.IProblem;
import org.sat4j.specs.ISolver;
import org.sat4j.specs.TimeoutException;

public class SAT {

	public int SAT(ArrayList<int[]> clauses, Game game, Cell c) {
		int call = 0;
		Logic3 l = new Logic3(game);
		final int MAXVAR = 1000000; // max number of variables
		final int NBCLAUSES = 500000; // number of clauses
		ISolver solver = SolverFactory.newDefault(); // prepare the solver to accept MAXVAR variables.
		solver.newVar(MAXVAR);
		solver.setExpectedNumberOfClauses(NBCLAUSES);

		for (int i = 0; i < clauses.size(); i++) {
			int[] claus = clauses.get(i);

			try {
				solver.addClause(new VecInt(claus));
			} catch (ContradictionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		IProblem problem = solver;
		try {
			if (problem.isSatisfiable()) {
			} else {
				call++;
				game.mark(c.x, c.y);
			}
		} catch (TimeoutException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return call;
	}
	
}

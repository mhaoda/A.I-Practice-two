/*
 * This is a class for creating the object cell.
 */
public class Cell {
	int x,y;
	boolean cover;
	String value;
	public Cell(int x, int y, String value) {
		super();
		this.x = x;
		this.y = y;
		this.value = value;
	}
	
	public int getValue() {
		if (value.equals("d") || value.equals("g")) {
			return 0;
		}
		
		return Integer.parseInt(value);
	}

	public void setValue(String value) {
		this.value = value;
	}

	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	
	public String toString() {
		return "("+this.x+", "+this.y+")";
	}
	
}

import java.util.ArrayList;
import java.util.Iterator;

import org.logicng.formulas.Formula;
import org.logicng.formulas.FormulaFactory;
import org.logicng.io.parsers.ParserException;
import org.logicng.io.parsers.PropositionalParser;

public class LoginNG{
	public ArrayList loginNG(String KBU) throws ParserException {
		final FormulaFactory f = new FormulaFactory(); 
		final PropositionalParser p = new PropositionalParser(f); 
		final Formula formula = p.parse(KBU); 
		final Formula cnf = formula.cnf(); 
		Iterator<Formula> iterator = cnf.iterator();
		int[] dimacs = null;
		ArrayList<int[]> clauses = new ArrayList<int[]>();
		while(iterator.hasNext()){
			Formula clause=iterator.next(); 

			String clauseStr = clause.toString();
			clauseStr = clauseStr.replaceAll("~", "-");
			String[] clas = clauseStr.split("\\|");
			dimacs = new int[clas.length];
			for(int i=0;i<clas.length;i++) {
				String trim = clas[i].trim();
				String trouble = "@RESERVED_CNF_";
				if(trim.contains(trouble)) {
					trim = "999999";
				}
				dimacs[i] = Integer.parseInt(trim);
			}
			clauses.add(dimacs);
		}
		return clauses;
	}
	
}

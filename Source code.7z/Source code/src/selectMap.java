/*
 * This is the class that help logic agent get the map.
 */
public class selectMap {
	public World select(String args) {
		World map = null;
		String num = args.replaceAll("[^0-9]", "");
		if(num.equals("1")) {
			if(args.contains("EASY")) {
				map = World.EASY1;
			}
			if(args.contains("MEDIUM")) {
				map = World.MEDIUM1;
			}
			if(args.contains("HARD")) {
				map = World.HARD1;
			}
		}
		if(num.equals("2")) {
			if(args.contains("EASY")) {
				map = World.EASY2;
			}
			if(args.contains("MEDIUM")) {
				map = World.MEDIUM2;
			}
			if(args.contains("HARD")) {
				map = World.HARD2;
			}
		}
		if(num.equals("3")) {
			if(args.contains("EASY")) {
				map = World.EASY3;
			}
			if(args.contains("MEDIUM")) {
				map = World.MEDIUM3;
			}
			if(args.contains("HARD")) {
				map = World.HARD3;
			}
		}
		if(num.equals("4")) {
			if(args.contains("EASY")) {
				map = World.EASY4;
			}
			if(args.contains("MEDIUM")) {
				map = World.MEDIUM4;
			}
			if(args.contains("HARD")) {
				map = World.HARD4;
			}
		}
		if(num.equals("5")) {
			if(args.contains("EASY")) {
				map = World.EASY5;
			}
			if(args.contains("MEDIUM")) {
				map = World.MEDIUM5;
			}
			if(args.contains("HARD")) {
				map = World.HARD5;
			}
		}
		if(num.equals("6")) {
			if(args.contains("EASY")) {
				map = World.EASY6;
			}
			if(args.contains("MEDIUM")) {
				map = World.MEDIUM6;
			}
			if(args.contains("HARD")) {
				map = World.HARD6;
			}
		}
		if(num.equals("7")) {
			if(args.contains("EASY")) {
				map = World.EASY7;
			}
			if(args.contains("MEDIUM")) {
				map = World.MEDIUM7;
			}
			if(args.contains("HARD")) {
				map = World.HARD7;
			}
		}
		if(num.equals("8")) {
			if(args.contains("EASY")) {
				map = World.EASY8;
			}
			if(args.contains("MEDIUM")) {
				map = World.MEDIUM8;
			}
			if(args.contains("HARD")) {
				map = World.HARD8;
			}
		}
		if(num.equals("9")) {
			if(args.contains("EASY")) {
				map = World.EASY9;
			}
			if(args.contains("MEDIUM")) {
				map = World.MEDIUM9;
			}
			if(args.contains("HARD")) {
				map = World.HARD9;
			}
		}
		if(num.equals("10")) {
			if(args.contains("EASY")) {
				map = World.EASY10;
			}
			if(args.contains("MEDIUM")) {
				map = World.MEDIUM10;
			}
			if(args.contains("HARD")) {
				map = World.HARD10;
			}
		}
		
		return map;
	}
}

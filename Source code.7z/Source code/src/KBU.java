/*
 * This is the class for generating knowledge base.
 */
import java.util.ArrayList;

public class KBU {
	//Connecting every single knowledge sentence. 
	public String creatKBU(Game game) {
		KBU k = new KBU();
		String KBU = "";
		ArrayList<Cell> borderCell = getBorder(game);
		for(int i=0;i<borderCell.size();i++) {
			KBU = KBU + k.getKBU(borderCell.get(i).x, borderCell.get(i).y, game);
		}
		KBU = KBU.replaceFirst("&", "");
		return KBU;
	}
	//Generating the knowledge sentence of the cell in x,y.
	public String getKBU(int x, int y, Game game) {
		String KBU = "";
		String subKBU = "";
		ArrayList<Cell> around = getNeighbours(x, y, game);
		ArrayList<Cell> neighbours = getCandinates(x, y, game);
		//get the cell value
		int value;
		if(game.map[x][y].equals("g")) {
			value = 0;
		}else {
		    value = Integer.parseInt(game.map[x][y]);
		}
		//get the number of the cover cell
		//System.out.println(game.map[x][y] +" ," +neighbours.size());
		int coverNum = 0;
		for(int i=0;i<around.size();i++) {
			if(game.cover[around.get(i).x][around.get(i).y]) {
				coverNum++;
			}
		}
		//get the number of the marked cell
		int markNum = 0;
		for(int i=0;i<around.size();i++) {
			if(game.mark[around.get(i).x][around.get(i).y]) {
				markNum++;
			}
		}
		//In the case that the cell's value is 0.
		if(value==0) {
			for(int i=0;i<neighbours.size();i++) {
				if(subKBU!="") {
					subKBU = subKBU + "&";
				}
				
				subKBU = subKBU + "~" + "D" + neighbours.get(i).x + neighbours.get(i).y;
			}
			KBU = KBU + "&" + "(" + subKBU + "&" + "~D" + x + y +")";
			subKBU = "";
		}
		//In the case that all covered cells are danger.
		if(coverNum<=value-markNum) {
			for(int i=0;i<neighbours.size();i++) {
				if(subKBU!="") {
					subKBU = subKBU + "&";
				}
				
				subKBU = subKBU + "D" + neighbours.get(i).x + neighbours.get(i).y ;
			}
			KBU = KBU + "|" + "(" + subKBU + ")";
			subKBU = "";
		}
		//In the case that the has different possibilities.
		if(coverNum>value-markNum&&value!=0) {
			String possibility = "";
			int count = 0;
				switch (value-markNum) {
				case 1:
					for(int i=0;i<neighbours.size();i++) {
						String subKBU_1 = "";
						String subKBU_2 = "";
							subKBU_1 = "D" + neighbours.get(i).x + neighbours.get(i).y;
							
						for(int j=0;j<neighbours.size();j++) {
							if(j!=i) {
								subKBU_2 = subKBU_2 + "&" + "~D" + neighbours.get(j).x + neighbours.get(j).y;
							}
							
						}
						possibility = possibility + "(" +subKBU_1 + subKBU_2 + ")";
						if(i!=neighbours.size()-1) {
							possibility = possibility + "|";
						}
					}
					KBU = KBU +" &" + "(" + possibility + ")";
					break;
			case 2:
				int pos2 = neighbours.size()*(neighbours.size()-1)/2;
				for(int i=0;i<neighbours.size();i++) {
					String subKBU_1="";
					subKBU_1 = "D" + neighbours.get(i).x + neighbours.get(i).y;
					for(int j=i+1;j<neighbours.size();j++) {
						String subKBU_2="";
						String subKBU_3 = "";
						if(j!=i) {
							subKBU_2 ="&"+ "D" + neighbours.get(j).x + neighbours.get(j).y;
							for(int a=0;a<neighbours.size();a++) {
								if(a!=i&&a!=j) {
									subKBU_3 = subKBU_3 + "&" + "~D" + neighbours.get(a).x + neighbours.get(a).y;
								}
							}
							possibility = possibility + "(" +subKBU_1 + subKBU_2 + subKBU_3 + ")";
							
						}
						count++;
						if(count!=pos2) {
							possibility = possibility + "|";
						}
						
					}
					
				}
				KBU = KBU +" &" + "(" + possibility + ")";
				break;
			case 3:
				int pos3 = neighbours.size()*(neighbours.size()-1)*(neighbours.size()-2)/6;
				for(int i=0;i<neighbours.size();i++) {
					String subKBU_1="";
					subKBU_1 = "D" + neighbours.get(i).x + neighbours.get(i).y;
					for(int j = i+1;j<neighbours.size();j++) {
						String subKBU_2="";
						String subKBU_3 = "";
						if(j!=i) {
							subKBU_2 ="&"+ "D" + neighbours.get(j).x + neighbours.get(j).y;
							for(int a=j+1;a<neighbours.size();a++) {
								String subKBU_4 = "";
								if(a!=i&&a!=j) {
									subKBU_3 = "&" + "D" + neighbours.get(a).x + neighbours.get(a).y;
									for(int w = 0; w<neighbours.size();w++) {
										if(w!=i&&w!=j&&w!=a) {
										subKBU_4 = subKBU_4 + "&" + "~D" + neighbours.get(w).x + neighbours.get(w).y;
										}
									}
									possibility = possibility + "(" +subKBU_1 + subKBU_2 + subKBU_3 + subKBU_4 + ")";
								}
							}
						}
					}
					count++;
					if(count!=pos3) {
						possibility = possibility + "|";
					}
				}
				KBU = KBU +" &" + "(" + possibility + ")";
				break;
			case 4:
				int pos4 = neighbours.size()*(neighbours.size()-1)*(neighbours.size()-2)*(neighbours.size()-3)/24;
				for(int i=0;i<neighbours.size();i++) {
					String subKBU_1="";
					subKBU_1 = "D" + neighbours.get(i).x + neighbours.get(i).y;
					for(int j = i+1;j<neighbours.size();j++) {
						String subKBU_2="";
						String subKBU_3 = "";
						if(j!=i) {
							subKBU_2 ="&"+ "D" + neighbours.get(j).x + neighbours.get(j).y;
							for(int a=j+1;a<neighbours.size();a++) {
								String subKBU_4 = "";
								if(a!=i&&a!=j) {
									subKBU_3 = "&" + "D" + neighbours.get(a).x + neighbours.get(a).y;
									for(int w = a+1; w<neighbours.size();w++) {
										String subKBU_5 = "";
										if(w!=i&&w!=j&&w!=a) {
											subKBU_4 = "&" + "D" + neighbours.get(w).x + neighbours.get(w).y;
											for(int r = 0; r<neighbours.size();r++) {
												if(r!=i&&r!=j&&r!=a&&r!=w) {
													subKBU_5 = subKBU_5 + "&" + "~D" + neighbours.get(r).x + neighbours.get(r).y;
												}
											}
											possibility = possibility + "(" +subKBU_1 + subKBU_2 + subKBU_3 + subKBU_4 + subKBU_5 + ")";
											count++;
											if(count!=pos4) {
												possibility = possibility + "|";
											}
										}
									}
								}
							}
						}
					}
				}
				KBU = KBU +" &" + "(" + possibility + ")";
				break;
			case 5:
				int pos5 = neighbours.size()*(neighbours.size()-1)*(neighbours.size()-2)*(neighbours.size()-3)*(neighbours.size()-4)/120;
				for(int i=0;i<neighbours.size();i++) {
					String subKBU_1="";
					subKBU_1 = "D" + neighbours.get(i).x + neighbours.get(i).y;
					for(int j = i+1;j<neighbours.size();j++) {
						String subKBU_2="";
						String subKBU_3 = "";
						if(j!=i) {
							subKBU_2 ="&"+ "D" + neighbours.get(j).x + neighbours.get(j).y;
							for(int a=j+1;a<neighbours.size();a++) {
								String subKBU_4 = "";
								if(a!=i&&a!=j) {
									subKBU_3 = "&" + "D" + neighbours.get(a).x + neighbours.get(a).y;
									for(int w = a+1; w<neighbours.size();w++) {
										String subKBU_5 = "";
										if(w!=i&&w!=j&&w!=a) {
											subKBU_4 = "&" + "D" + neighbours.get(w).x + neighbours.get(w).y;
											for(int r = w+1; r<neighbours.size();r++) {
												String subKBU_6 = "";
												if(r!=i&&r!=j&&r!=a&&r!=w) {
													subKBU_5 = "&" + "D" + neighbours.get(r).x + neighbours.get(r).y;
													for(int t = 0;t<neighbours.size();t++) {
														if(t!=i&&t!=j&&t!=a&&t!=w&&t!=r) {
															subKBU_6 = subKBU_6 + "&" + "~D" + neighbours.get(t).x + neighbours.get(t).y;
														}
													}
													possibility = possibility + "(" +subKBU_1 + subKBU_2 + subKBU_3 + subKBU_4 + subKBU_5 + subKBU_6 + ")";
													count++;
													if(count!=pos5) {
														possibility = possibility + "|";
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
				KBU = KBU +" &" + "(" + possibility + ")";
				break;
			default:
				break;
			}
		}
		return KBU;
	}
	//Collecting the neighbours around the cell in m,n.
	public ArrayList<Cell> getNeighbours(int m, int n, Game game) {
		ArrayList<Cell> candinates = new ArrayList<Cell>();
		for (int x = m - 1; x <= m + 1; x++) {
			if (x >= 0 && x < game.map.length) {
				for (int y = n - 1; y <= n + 1; y++) {
					if (y >= 0 && y < game.map[x].length) {
						candinates.add(new Cell(x, y, game.map[x][y]));
					}
				}
			}
		}
		return candinates;
	}
	//Collecting the border of the uncovered cells.
	public ArrayList<Cell> getBorder(Game game){
		ArrayList<Cell> uncoveredList = new ArrayList<Cell>();
		for(int i=0;i<game.cover.length;i++) {
			for(int z=0;z<game.cover[i].length;z++) {
				if(!game.cover[i][z]) {
					uncoveredList.add(new Cell(i, z, game.map[i][z]));
				}
			}
		}
		ArrayList<Cell> borderCell = new ArrayList<Cell>();
		for(int i = 0;i<uncoveredList.size();i++) {
			if(!game.mark[uncoveredList.get(i).x][uncoveredList.get(i).y]) {
			ArrayList<Cell> n = getCandinates(uncoveredList.get(i).x, uncoveredList.get(i).y, game);
			int unsearched = 0;
			for(int s = 0;s<n.size();s++) {
				if(game.cover[n.get(s).x][n.get(s).y]) {
					unsearched ++;
				}
			}
			if(unsearched>0) {
				borderCell.add(uncoveredList.get(i));
			}
		}
	}
		return borderCell;
}
	//Collecting the covered neighbours that do not include the probing cell.
	public ArrayList<Cell> getCandinates(int m, int n, Game game) {
		ArrayList<Cell> candinates = new ArrayList<Cell>();
		for (int x = m - 1; x <= m + 1; x++) {
			if (x >= 0 && x < game.map.length) {
				for (int y = n - 1; y <= n + 1; y++) {
					if (y >= 0 && y < game.map[x].length) {
						if((x!=m||y!=n)&&game.cover[x][y]) {
						candinates.add(new Cell(x, y, game.map[x][y]));
						}
					}
				}
			}
		}
		return candinates;
	}
}
